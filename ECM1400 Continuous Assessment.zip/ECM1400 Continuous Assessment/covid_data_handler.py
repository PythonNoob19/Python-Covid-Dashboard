import csv
import json
import time
from datetime import datetime
import sched
import logging
import multiprocessing
import pickle
import pandas as pd
from sched import scheduler
from flask import redirect
from uk_covid19 import Cov19API
from covid_news_handling import *
from sched import scheduler



logging.basicConfig(
    filename="logging/record.log",
    level=logging.INFO,
    format='%(levelname)s:%(message)s')


def parse_csv_data(csv_filename):
    """
    This function accesses the covid data from its CSV file (nation_2021-10-28.csv)
    and then places each row into an array
    """

    with open(csv_filename, 'r') as file:
        filecontent = csv.reader(file)
        data = []
        for row in filecontent:
            string = ','.join(str(x) for x in row)
            data.append(string)

        return data


def process_covid_csv_data(covid_csv_data):

    row_one = covid_csv_data[1].split(",")
    current_hospital_cases = row_one[5]
    total_deaths = 0
    for x in range(1, len(covid_csv_data) - 1):
        row = covid_csv_data[x].split(",")
        if(row[4] != ""):
            total_deaths = int(row[4])
            break

    last7days_cases = 0
    for i in range(3, 10):
        row = covid_csv_data[i].split(",")
        last7days_cases += int(row[6])

    return last7days_cases, current_hospital_cases, total_deaths


def covid_api_request(
    location="Exeter",
    location_type="ltla"
    ):

    all_nations = [
        "areaType=" + location_type,
        "areaName=" + location,
    ]

    cases_and_deaths = {
        "areaCode": "areaCode",
        "areaName": "areaName",
        "areaType": "areaType",
        "date": "date",
        "cumDailyNsoDeathsByDeathDate": "cumDailyNsoDeathsByDeathDate",
        "hospitalCases": "hospitalCases",
        "newCasesBySpecimenDate": "newCasesBySpecimenDate"
    }

    api = Cov19API(
        filters=all_nations,
        structure=cases_and_deaths,
    )
    data = api.get_json()
    processed_dictionary = process_request_into_dictionary(data['data'])

    return processed_dictionary


def process_request_into_dictionary(data):
    format = {
        "areaCode": {},
        "areaName": {},
        "areaType": {},
        "date": {},
        "cumDailyNsoDeathsByDeathDate": {},
        "hospitalCases": {},
        "newCasesBySpecimenDate": {}}
    for i in range(0, len(data) - 1):
        format['areaCode'][i] = data[i]['areaCode']
        format['areaName'][i] = data[i]['areaName']
        format['areaType'][i] = data[i]['areaType']
        format['date'][i] = data[i]['date']
        format['cumDailyNsoDeathsByDeathDate'][i] = data[i]['cumDailyNsoDeathsByDeathDate']
        format['hospitalCases'][i] = data[i]['hospitalCases']
        format['newCasesBySpecimenDate'][i] = data[i]['newCasesBySpecimenDate']

    return format


def dict_to_csv(dict):
    header = [
        'areaCode',
        'areaName',
        'areaType',
        'date',
        'cumDailyNsoDeathsByDeathDate',
        'hospitalCases',
        'newCasesBySpecimenDate']

    with open('data_files/covidData.csv', 'w', encoding='UTF8') as f:
        writer = csv.writer(f)
        writer.writerow(header)

        for i in range(0, len(dict['areaCode']) - 1):
            row = [
                dict['areaCode'][i],
                dict['areaName'][i],
                dict['areaType'][i],
                dict['date'][i],
                dict['cumDailyNsoDeathsByDeathDate'][i],
                dict['hospitalCases'][i],
                dict['newCasesBySpecimenDate'][i]]
            writer.writerow(row)

    df = pd.read_csv('data_files/covidData.csv')
    df.dropna(axis=0, how='all', inplace=True)
    df.to_csv('data_files/covidData.csv', index=False)


def time_duration(update_interval):
    now = datetime.now()
    current_time = now.strftime("%H:%M")


    h = int(current_time[0:2])  
    m = int(current_time[3:5])  

    H = int(update_interval[0:2])  
    M = int(update_interval[3:5])  

    if M <= m and H <= h:   



        H += 23
        M += 60

        Ho = H - h
        Mo = M - m

        print("Time till update: " + str(Ho) + ":" + str(Mo))
        a = (Ho * 3600) + (Mo * 60)
        return (a)

    elif m <= M and h <= H:



        Ho = (H - h)
        Mo = (M - m)

        print("Time till update: " + str(Ho) + ":" + str(Mo))

        return ((Ho * 3600) + (Mo * 60))

    elif m <= M and H < h:



        H += 24

        Ho = (H - h)
        Mo = (M - m)

        print("Time till update: " + str(Ho) + ":" + str(Mo))

        return ((Ho * 3600) + (Mo * 60))

    elif M < m and h < H: 

        H -= 1
        M += 60

        Ho = (H - h)
        Mo = (M - m)

        print("Time till update: " + str(Ho) + ":" + str(Mo))

        return ((Ho * 3600) + (Mo * 60))


def update_Data():
    dict_to_csv(covid_api_request())
    global last7days_cases, current_hospital_cases, total_deaths
    last7days_cases, current_hospital_cases, total_deaths = process_covid_csv_data(
        parse_csv_data("data_files/covidData.csv"))

    output = []
    output.append(last7days_cases)
    output.append(current_hospital_cases)
    output.append(total_deaths)

    with open("data.pkl", "wb") as f:
        pickle.dump([last7days_cases, current_hospital_cases, total_deaths], f)

    print("last 7 days cases: " + str(last7days_cases))
    print("current hospital cases: " + str(current_hospital_cases))
    print("total deaths: " + str(total_deaths))


    logging.basicConfig(
    filename="logging/data.log",
    level=logging.INFO,
    format='%(levelname)s:%(message)s')

    logging.info(output)


def update_News():
    news_articles = update_news()

    with open("data_files/newsdata.pkl", "wb") as f:
        pickle.dump(news_articles, f)


def schedule_covid_update(
    update_interval,
    update_name,
    *options):

    if len(options) == 2:
        print("update name: " + update_name)
        print("Update Type: News and Data")

        logging.info(
            "Update name: " +
            update_name +
            "-" +
            "Update Type: News and Data")

        p = multiprocessing.Process(target=thread_1, args=[update_interval])
        p.start()

    elif options[0] == "news" and len(options) == 1:
        print("update name: " + update_name)
        print("Update Type: News")
        logging.info("update name: " + update_name + "-" + "Update Type: News")
        p = multiprocessing.Process(target=thread_2, args=[update_interval])
        p.start()

    elif options[0] == "covid-data" and len(options) == 1:
        print("update name: " + update_name)
        print("Update Type: Data")
        logging.info("update name: " + update_name + "-" + "Update Type: Data")
        p = multiprocessing.Process(target=thread_3, args=[update_interval])
        p.start()

    else:
        print("No Update")


def thread_1(update_interval):
    s = sched.scheduler(time.time, time.sleep)
    s.enter(time_duration(update_interval), 1, update_Data)
    s.enter(time_duration(update_interval), 1, update_News)
    s.run()


def thread_2(update_interval):
    s = sched.scheduler(time.time, time.sleep)
    s.enter(time_duration(update_interval), 1, update_News)
    s.run()


def thread_3(update_interval):
    s = sched.scheduler(time.time, time.sleep)
    s.enter(time_duration(update_interval), 1, update_Data)
    s.run()
