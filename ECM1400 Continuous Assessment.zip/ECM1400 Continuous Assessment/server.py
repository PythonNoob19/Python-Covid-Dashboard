import pickle
import multiprocessing
import logging
import init
from flask import Flask, render_template, request, redirect
from covid_data_handler import *

app = Flask(__name__, template_folder='templates')

global updates
updates = []

logging.basicConfig(
    filename="logging/record.log",
    level=logging.INFO,
    format='%(levelname)s:%(message)s')


@app.route('/result', methods=['POST', 'GET'])
def index():

    if request.method == 'POST':
        request_result = request.form
        updates.append(
            {'title': request_result['two'], "content": request_result['update']})

        if 'news' in request_result.keys() and 'covid-data' in request_result.keys():
            schedule_covid_update(
                request_result['update'],
                request_result['two'],
                request_result['news'],
                request_result['covid-data'])
                
            return redirect("/")

        elif 'covid-data' in request_result.keys() and 'news' not in request_result.keys():
            schedule_covid_update(
                request_result['update'],
                request_result['two'],
                request_result['covid-data'])

            return redirect("/")

        elif 'news' in request_result.keys() and 'covid-data' not in request_result.keys():
            schedule_covid_update(
                request_result['update'],
                request_result['two'],
                request_result['news'])

            return redirect("/")

    else:
        return redirect("/")


@app.route('/', methods=['GET', 'POST'])
def generate(local_7day_infections=0, hospital_cases=0,
             deaths_total=0, national_7day_infections=0):

    with open("config.json", "r") as r:
        config = json.load(r)

    with open("data_files/data.pkl", "rb") as f:
        obj0, obj1, obj2 = pickle.load(f)

    with open("data_files/newsdata.pkl", "rb") as a:
        news = pickle.load(a)

    return render_template(
        "index.html",
        favicon=config["favicon"],
        updates=updates,
        location="Exeter",
        nation_location="United Kingdom",
        image="covid-19.jpg",
        local_7day_infections=obj0,
        hospital_cases=obj1,
        deaths_total=obj2,
        news_articles=news)


@app.route("/refresh")
def refresh():

    with open("config.json", "r") as r:
        config = json.load(r)

    logging.info("Refreshing has started")

    while True:
        time.sleep(int(config["refresh_time"]))
        redirect("/")


if __name__ == '__main__':

    init.reset()
    app.run()
