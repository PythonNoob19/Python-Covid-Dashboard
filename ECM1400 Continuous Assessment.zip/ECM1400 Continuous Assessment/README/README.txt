Author: Daniel Gilder

Project title: ECM1400 Continuous Assessment



Project description:
The project is designed to be a personalised covid dashboard, dashboards are automated systems that help us visualise input data streams. This dashboard coordinates information about
COVID infection rates from the Public Health England API and news stories about Covid from a given news API.


How to start application:
0. Enter your API key in "config.json" for the newsapi in the "news_api_key" attribute, if you don't have an API key you can gain one from https://newsapi.org/
1. Run server.py in the console
2. Enter the servers default local address, usually http://127.0.0.1:5000/, in your favourite browser
3. You should see a webpage displayed in your browser
4. For the final step, simply enter 127.0.0.1:5000/refresh to start the webpages refreshing mechanism, now the web application should be ready to use.
5. Now you can enter as many updates as you please

Third-Party modules used:
-newsapi
-uk_covid19
-flask



Structure of the project:
The project is split into 4 python modules.
-server.py: used to run and start the application, the module operates a flask server
-covid_data_handler.py: this module is used to process data taken from csv and json files sent from the 'uk_covid19' API
-covid_news_handling.py: this module is used to process news data from the 'newsapi' API
-init.py: this module isn't nescescary to operate the application how ever, it can be used to reset all the data being stored locally if there are glitches in the data being displayed. It can be run once , and resets the application

The project also  has a configuration file, named 'config.json'. The file can be used to modify, the news API key, the image displayed, the tab icon and refresh rate of the page.
All data is stored within the data_files/ directory, using .pkl and .csv formats
Logging data is stored in the logging/ directory using the .log format
Any image or images to be displayed MUST be located in static/images/ directory, similary the index.html file MUST ALWAYS be stored in templates/ directory



Code issues:
-The cancel update button is non-functional
-The repeat update button is non-functional
-The scheduled updates may also be sometimes slightly delayed




Other things to note:
-The code has been styled in standard PEP8 format


The project can also be accessed from GitHub: https://github.com/PythonNoob19/Python-Covid-Dashboard