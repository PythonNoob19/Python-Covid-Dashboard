from newsapi import NewsApiClient
from dotenv import load_dotenv
import os
import json


global news_articles_unprocessed
news_articles_unprocessed = {'title': {}, 'content': {}}
global news_articles_formated
news_articles_formated = []


def news_API_request(terms="COVID-19"):

    with open("config.json", "r") as f:
        data = json.load(f)
    news_api = NewsApiClient(api_key=data['news_api_key'])
    top_headlines = news_api.get_top_headlines(q=terms)
    return top_headlines


def update_news():

    news = news_API_request()

    for i in range(0, len(news['articles']) - 1):
        if "title" in news['articles'][i]:
            news_articles_unprocessed['title'][i] = news['articles'][i]['title']

        else:
            news_articles_unprocessed['title'][i] = news['articles'][i]['author']

        if "description" in news['articles'][i]:
            news_articles_unprocessed['content'][i] = news['articles'][i]['description']

        else:
            news_articles_unprocessed['content'][i] = news['articles'][i]['url']

    reformat(news_articles_unprocessed)

    return news_articles_formated


def reformat(newsArticles):
    for i in range(0, len(news_articles_unprocessed['title']) - 1):
        news = {
            "title": news_articles_unprocessed['title'][i],
            "content": news_articles_unprocessed['content'][i]}
        news_articles_formated.append(news)
