import pickle


def reset():
    with open("data_files/data.pkl", "wb") as f:
        pickle.dump(["","", ""],f)

    with open("data_files/newsdata.pkl", "wb") as f:
        pickle.dump([],f)

